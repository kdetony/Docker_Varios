<a href="http://creativealiens.com/demo/drifolio/"><img src="http://creativealiens.com/demo/drifolio/preview.png" alt="Drifolio – Free Responsive Dribbble Portfolio Template"></a>

What & Why Drifolio?
---------------------------
Drifolio - stands for Dribbble Portfolio.

There are many designers around me don't have enough time to setup and manage their own website. For them it could be a great template that needs one time setup.

You just need to set your info and dribbble username, that's all. And after that, whenever you post something on dribbble, it'll come automatically to your website as well. There's nothing to do there again :)

Live demo: http://creativealiens.com/demo/drifolio/

View the post on dribbble: http://drbl.in/mVHv

This is a free Bootstrap powered HTML template from EvenFly. Feel free to download, modify and use it for yourself or your clients as long there is no money involved.

Please don't try to sale it from anywhere; because I want it to be free, forever. If you sale it, that's me who deserves the money, not you :)

Documentetion and credits
---------------------------
Here is a short documentetion about basic changes on the template
http://goo.gl/FhmJav

Feel free to drop an email to info@creativealiens.com
if you have any question/suggestions.


THANKS!
---------------------------
If you like this template, you may like our other works as well.
Keep your eyes on 
http://creativealiens.com

Or follow me on
https://www.facebook.com/MamunSrizon or 
https://twitter.com/MamunSrizon
